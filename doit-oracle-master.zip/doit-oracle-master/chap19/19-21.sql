SELECT func_aftertax(3000)
  FROM DUAL;