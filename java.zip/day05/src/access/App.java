package access;

public class App {

	public static void main(String[] args) {
		Employee e = new Employee();


	}

}
