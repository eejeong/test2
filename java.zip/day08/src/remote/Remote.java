package remote;

public interface Remote {
	public void turnOn();
	public void turnOff();
}
