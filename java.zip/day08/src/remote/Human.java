package remote;

public class Human {

	public static void main(String[] args) {
		Remote remote = new Tv();
		remote.turnOff();
		remote.turnOn();
	}

}
