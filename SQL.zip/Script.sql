/* Q1-1
(1) 논리설계
(2) 데이터 모델링
Q1-2
(1) E-R 모델
(2) E-R 모델
(3) Entity
Q1-3
(1) E-R Diagram (Entity-Relation Diagram)
(2) 관계
Q1-4
(1) 카디널리티(Cardinality)
(2) 옵셔널리티 (Optionality)
Q1-5 
(1) 스키마
(2) 테이블
Q1-6
(1) Table
(2) Index
(3) Sequence
*/