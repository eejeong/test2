package oop1;

public class App {

	public static void main(String[] args) {
		Car car1 = new Car();
		car1.go();
		car1.stop();
		
		Car car2 = new Car();
		car2.go();
		car2.stop();
	}

}
