package db;

public interface DAO {
	public void insert(Object obj);
	public void delete(Object obj);
	public void update(Object obj);
}
