package cal;

public class InfinityException extends Exception {
	public InfinityException() {
		
	}
	public InfinityException(String msgcode) {
		super(msgcode);
	}
	
}
