package bank;

public class ShortfallException extends Exception {
	public ShortfallException() {
		
	}

}
