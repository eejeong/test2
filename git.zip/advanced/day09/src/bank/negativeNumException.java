package bank;

public class negativeNumException extends Exception {
	public negativeNumException () {
		
	}
	public negativeNumException(String msgcode) {
		super(msgcode);
	}

}
