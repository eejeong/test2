package com.kbstar.frame;

public interface SearchService {
	public void search();
}
