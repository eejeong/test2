package com.kbstar.service;

import com.kbstar.dao.ShopDAO;
import com.kbstar.dto.ShopDTO;
import com.kbstar.frame.DAO;
import com.kbstar.frame.Service;

public class ShopService implements Service<String, ShopDTO> {
	DAO<String, ShopDTO> dao;
	
	public ShopService() {
		dao = new ShopDAO();
	}

	@Override
	public void register(ShopDTO v) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove(String k) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modify(ShopDTO v) {
		// TODO Auto-generated method stub
		
	}
	
}
