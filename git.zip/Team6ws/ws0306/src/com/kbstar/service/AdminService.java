package com.kbstar.service;

public class AdminService {

}
