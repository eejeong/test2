package com.kbstar.dto;

public class ShopDTO {
	private String id;
	private String name;
	private String product;
	private double price;
	public ShopDTO() {
	}
	public ShopDTO(String id, String name, String product, double price) {
		this.id = id;
		this.name = name;
		this.product = product;
		this.price = price;
	}
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getProduct() {
		return product;
	}
	public double getPrice() {
		return price;
	}
	@Override
	public String toString() {
		return "ShopDTO [id=" + id + ", name=" + name + ", product=" + product + ", price=" + price + "]";
	}
	
}
