package com.kbstar.dto;

public class UserDTO {

}
