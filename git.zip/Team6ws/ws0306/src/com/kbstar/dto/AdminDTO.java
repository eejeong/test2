package com.kbstar.dto;

public class AdminDTO {

}
