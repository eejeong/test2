package com.kbstar.dao;

public class UserDAO {

}
