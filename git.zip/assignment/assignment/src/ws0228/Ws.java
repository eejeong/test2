package ws0228;

public class Ws {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
