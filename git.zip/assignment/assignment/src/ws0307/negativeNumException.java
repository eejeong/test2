package ws0307;

public class negativeNumException extends Exception {
	public negativeNumException () {
		
	}
	public negativeNumException(String msgcode) {
		super(msgcode);
	}

}
