package com.kbstar.frame;

public class Msg {
	public static String registerMsg1 = "가입을 축하합니다.";
	public static String registerMsg2 = "가입을 진심으로 축하합니다.";

	public static String removeMsg1 = "탈퇴가 완료되었습니다.";
	public static String removeMsg2 = "탈퇴가 완료되었습니다.";
	
}
