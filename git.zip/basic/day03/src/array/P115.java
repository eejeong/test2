package array;

public class P115 {

	public static void main(String[] args) {
		String strs[] = new String[3];
		strs[0] = "abc";
		strs[1] = "def";
		strs[2] = "ghi";
	}

}
