package array;

public class P103 {

	public static void main(String[] args) {
	
//		int arr[] = new int[3]; 
//		int []arr = new int[3];
//	
//		arr[0] = 10;
//		arr[1] = 20;		
//		arr[2] = 30;
		int arr[] = {10,20,30};
		System.out.println(arr);
		

	for(int data:arr) {
		System.out.printf("%d \t", data);
	}
}
}