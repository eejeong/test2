package variable;

public class P80 {

	public static void main(String[] args) {
		int credit = 900;
		String grade = (credit >= 800) ? "High" : "Low";

		System.out.println(grade);
	}

}