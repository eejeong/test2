package variable;


public class P78 {

	public static void main(String[] args) {
		int a = 10;
		a = -- a + 1;
		System.out.println(a);

		int b = 20;
		b += 1;
	}

}