package variable;

public class P79 {

	public static void main(String[] args) {
		int credit = 0;
		String grade = "";
		if(credit >= 800) {
			grade = "High";
		}else {
			grade = "Low";
		}
		System.out.println(grade);
	}

}