package day02;

public class P55 {

	public static void main(String[] args) {
		int a = 2000000000;
		int b = 2000000000;
		System.out.println((long)a+b);
	}

}
