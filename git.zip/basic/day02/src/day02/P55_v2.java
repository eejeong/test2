package day02;

public class P55_v2 {

	public static void main(String[] args) {
		long aa = 2000000000;
		long bb = 2000000000;		

		long result = aa + bb;
		System.out.println(result);
	}

}
