"use strict;";

let a = parseInt(prompt("첫번째"));
let b = parseInt(prompt("두번째"));

console.log(a);
console.log(b);

function plus() {
  alert(a + b);
}
function minus() {
  alert(a - b);
}
function multiply() {
  alert(a * b);
}
function division() {
  alert(a / b);
}
