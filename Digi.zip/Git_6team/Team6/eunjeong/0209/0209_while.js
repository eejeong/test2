//while문은 조건값이 맞지 않으면 실행되지 않음. ex num이 9999잏상인 경우 실행 x
// let num = 1;

// while (num <= 9999) {
//   console.log(num);
//   num++;
// }

do {
  console.log("무조건");
  console.log("한 번은 실행");
} while (false);
