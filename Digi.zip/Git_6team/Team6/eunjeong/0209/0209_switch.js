// let food = "orange";
// switch (food) {
//   case "melon":
//     console.log("fruit");
//     break;
//   case "apple":
//     console.log("fruit");
//     break;
//   case "banana":
//     console.log("fruit");
//     break;
//   case "carrot":
//     console.log("vegetable");
//     break;
//   default:
//     console.log("It's not fruits and vegetables.");
//     break;
// }

let score = 80;
switch (score) {
  case 90:
  case 91:
  case 92:
  case 93:
  case 94:
  case 95:
  case 96:
  case 97:
  case 98:
  case 99:
    console.log("A++ 학점");
    break;
  default:
    console.log("멍청아");
    break;
}
