/* let num = 1;
while (num <= 9999) {
  console.log(num);
  num++;
} */
// while문은 처음에 조건이 맞지 않으면 애초에 실행이 되지 않을 수 있음
// 특정 구간 반복을 하겠다 하는 경우에는 적절하지 않을 수 있음

do {
  console.log("무조건");
  console.log("한 번은 실행");
} while (false);
