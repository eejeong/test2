# Rabbit by Beard Chicken

A Pen created on CodePen.io. Original URL: [https://codepen.io/katydecorah/pen/nKGxJd](https://codepen.io/katydecorah/pen/nKGxJd).

Dribbble shot: http://dribbble.com/shots/1316513